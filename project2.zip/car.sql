INSERT INTO `car` VALUES (3, '熊猫动物面膜25ml*10片', 99.00, 1, 'http://a2.vimage1.com/upload/merchandise/pdc/330/273/7930915237186273330/0/8809237828362-5.jpg', '4.3折', '￥229.00', '2018-4-16 15:30:20');
